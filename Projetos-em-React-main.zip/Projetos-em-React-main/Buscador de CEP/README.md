## Buscador de CEP em React

![2023-05-01 10-32-56](https://user-images.githubusercontent.com/83782001/235459696-536b13d5-c9e1-48d5-b085-8f08b778944f.gif)
